import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _6175141f = () => interopDefault(import('..\\pages\\layout' /* webpackChunkName: "" */))
const _041271d8 = () => interopDefault(import('..\\pages\\home' /* webpackChunkName: "" */))
const _7dcb3858 = () => interopDefault(import('..\\pages\\login' /* webpackChunkName: "" */))
const _8590e158 = () => interopDefault(import('..\\pages\\profile' /* webpackChunkName: "" */))
const _7afa6bd8 = () => interopDefault(import('..\\pages\\settings' /* webpackChunkName: "" */))
const _55a63a62 = () => interopDefault(import('..\\pages\\editor' /* webpackChunkName: "" */))
const _b7fc5abe = () => interopDefault(import('..\\pages\\article' /* webpackChunkName: "" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/",
    component: _6175141f,
    children: [{
      path: "",
      component: _041271d8,
      name: "home"
    }, {
      path: "/login",
      component: _7dcb3858,
      name: "login"
    }, {
      path: "/register",
      component: _7dcb3858,
      name: "register"
    }, {
      path: "/profile/:username",
      component: _8590e158,
      name: "profile"
    }, {
      path: "/settings",
      component: _7afa6bd8,
      name: "settings"
    }, {
      path: "/editor",
      component: _55a63a62,
      name: "editor"
    }, {
      path: "/article/:slug",
      component: _b7fc5abe,
      name: "article"
    }]
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config.app && config.app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
